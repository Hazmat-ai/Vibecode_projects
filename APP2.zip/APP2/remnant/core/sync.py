"""
core/sync.py — Database merge / community sync logic.
Sync is additive and non-destructive. Transfer via filesystem (USB), not network.
"""

import json
import sqlite3
from typing import Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from core.db import Database


def merge_databases(local_db: "Database", source_path: str) -> dict:
    """
    Merge records from source_path into local_db.
    Returns a summary dict: {articles_added, skills_added, conflicts, communities_merged}.
    """
    summary = {"articles_added": 0, "skills_added": 0, "conflicts": 0, "communities_merged": 0}

    try:
        remote_conn = sqlite3.connect(source_path)
        remote_conn.row_factory = sqlite3.Row
    except Exception as e:
        raise RuntimeError(f"Cannot open source database: {e}")

    try:
        # --- Merge articles ---
        remote_articles = remote_conn.execute("SELECT * FROM articles").fetchall()
        for row in remote_articles:
            local = local_db.connection.execute(
                "SELECT * FROM articles WHERE id=?", (row["id"],)
            ).fetchone()
            if local is None:
                local_db.connection.execute(
                    "INSERT INTO articles VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                    tuple(row),
                )
                summary["articles_added"] += 1
            elif local["content"] != row["content"]:
                # Conflict: keep local, flag it
                local_db.insert_conflict(
                    "article",
                    row["id"],
                    local["content"],
                    row["content"],
                )
                summary["conflicts"] += 1

        # --- Merge skills ---
        remote_skills = remote_conn.execute("SELECT * FROM skills").fetchall()
        for row in remote_skills:
            local = local_db.connection.execute(
                "SELECT * FROM skills WHERE id=?", (row["id"],)
            ).fetchone()
            if local is None:
                local_db.connection.execute(
                    "INSERT INTO skills VALUES(?,?,?,?,?,?,?,?,?,?)",
                    tuple(row),
                )
                summary["skills_added"] += 1
            elif local["summary"] != row["summary"]:
                local_db.insert_conflict(
                    "skill",
                    row["id"],
                    local["summary"],
                    row["summary"],
                )
                summary["conflicts"] += 1

        # --- Merge communities (union of known_skills) ---
        remote_communities = remote_conn.execute("SELECT * FROM communities").fetchall()
        for row in remote_communities:
            local = local_db.connection.execute(
                "SELECT * FROM communities WHERE id=?", (row["id"],)
            ).fetchone()
            remote_known = set(json.loads(row["known_skills"]))
            if local is None:
                local_db.connection.execute(
                    "INSERT INTO communities VALUES(?,?,?,?,?)",
                    tuple(row),
                )
                summary["communities_merged"] += 1
            else:
                local_known = set(json.loads(local["known_skills"]))
                merged = local_known | remote_known
                if merged != local_known:
                    local_db.update_community_skills(row["id"], merged)
                    summary["communities_merged"] += 1

        local_db.connection.commit()
    finally:
        remote_conn.close()

    return summary
