"""
core/db.py — SQLite interface for REMNANT.
All data lives in a single .db file. This module owns schema creation and migration.
"""

import sqlite3
import json
import os
from typing import Optional
from datetime import date


SCHEMA_VERSION = "1"

_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS articles (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    domain TEXT NOT NULL,
    tags TEXT NOT NULL,
    civilization_score INTEGER NOT NULL,
    difficulty INTEGER NOT NULL,
    requires_skills TEXT NOT NULL,
    summary TEXT NOT NULL,
    content TEXT NOT NULL,
    sources TEXT NOT NULL,
    last_updated TEXT,
    custom INTEGER NOT NULL DEFAULT 0
);

CREATE VIRTUAL TABLE IF NOT EXISTS articles_fts USING fts5(
    id UNINDEXED,
    title,
    summary,
    content,
    tags,
    content='articles',
    content_rowid='rowid'
);

CREATE TABLE IF NOT EXISTS skills (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    domain TEXT NOT NULL,
    civilization_score INTEGER NOT NULL,
    requires TEXT NOT NULL,
    unlocks TEXT NOT NULL,
    summary TEXT NOT NULL,
    difficulty INTEGER NOT NULL,
    time_to_learn_days INTEGER NOT NULL,
    custom INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS communities (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    known_skills TEXT NOT NULL DEFAULT '[]',
    created_at TEXT,
    notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sync_conflicts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    record_type TEXT NOT NULL,
    record_id TEXT NOT NULL,
    local_value TEXT NOT NULL,
    remote_value TEXT NOT NULL,
    detected_at TEXT NOT NULL
);
"""

_FTS_TRIGGER_SQL = """
CREATE TRIGGER IF NOT EXISTS articles_fts_insert AFTER INSERT ON articles BEGIN
    INSERT INTO articles_fts(rowid, id, title, summary, content, tags)
    VALUES (new.rowid, new.id, new.title, new.summary, new.content, new.tags);
END;

CREATE TRIGGER IF NOT EXISTS articles_fts_update AFTER UPDATE ON articles BEGIN
    DELETE FROM articles_fts WHERE rowid = old.rowid;
    INSERT INTO articles_fts(rowid, id, title, summary, content, tags)
    VALUES (new.rowid, new.id, new.title, new.summary, new.content, new.tags);
END;

CREATE TRIGGER IF NOT EXISTS articles_fts_delete AFTER DELETE ON articles BEGIN
    DELETE FROM articles_fts WHERE rowid = old.rowid;
END;
"""


class Database:
    """Main database interface. Pass ':memory:' for testing."""

    def __init__(self, path: str = "data/remnant.db"):
        self.path = path
        if path != ":memory:":
            os.makedirs(os.path.dirname(path), exist_ok=True) if os.path.dirname(path) else None
        self._conn = sqlite3.connect(path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        self._initialize()

    # ------------------------------------------------------------------ #
    #  Schema management                                                   #
    # ------------------------------------------------------------------ #

    def _initialize(self):
        self._conn.executescript(_SCHEMA_SQL)
        self._conn.executescript(_FTS_TRIGGER_SQL)
        # Set schema version if not already set
        existing = self._conn.execute(
            "SELECT value FROM meta WHERE key='schema_version'"
        ).fetchone()
        if not existing:
            self._conn.execute(
                "INSERT INTO meta(key,value) VALUES('schema_version',?)",
                (SCHEMA_VERSION,),
            )
        self._conn.commit()

    def get_meta(self, key: str) -> Optional[str]:
        row = self._conn.execute(
            "SELECT value FROM meta WHERE key=?", (key,)
        ).fetchone()
        return row["value"] if row else None

    def set_meta(self, key: str, value: str):
        self._conn.execute(
            "INSERT OR REPLACE INTO meta(key,value) VALUES(?,?)", (key, value)
        )
        self._conn.commit()

    # ------------------------------------------------------------------ #
    #  Article CRUD                                                        #
    # ------------------------------------------------------------------ #

    def insert_article(self, article, replace: bool = False) -> bool:
        """Insert an Article dataclass. Returns True if inserted, False if skipped."""
        cmd = "INSERT OR REPLACE" if replace else "INSERT OR IGNORE"
        cur = self._conn.execute(
            f"{cmd} INTO articles VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
            self._article_to_row(article),
        )
        self._conn.commit()
        return cur.rowcount > 0

    def get_article(self, article_id: str):
        row = self._conn.execute(
            "SELECT * FROM articles WHERE id=?", (article_id,)
        ).fetchone()
        return self._row_to_article(row) if row else None

    def list_articles(
        self,
        domain: Optional[str] = None,
        min_cs: int = 0,
        limit: int = 50,
        offset: int = 0,
    ):
        q = "SELECT * FROM articles WHERE civilization_score >= ?"
        params = [min_cs]
        if domain:
            q += " AND domain=?"
            params.append(domain)
        q += " ORDER BY civilization_score DESC LIMIT ? OFFSET ?"
        params += [limit, offset]
        rows = self._conn.execute(q, params).fetchall()
        return [self._row_to_article(r) for r in rows]

    def search_articles(self, query: str, domain: Optional[str] = None, limit: int = 20):
        """Full-text search via FTS5."""
        q = """
            SELECT a.* FROM articles a
            JOIN articles_fts fts ON a.rowid = fts.rowid
            WHERE articles_fts MATCH ?
        """
        params = [query]
        if domain:
            q += " AND a.domain=?"
            params.append(domain)
        q += " ORDER BY a.civilization_score DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(q, params).fetchall()
        return [self._row_to_article(r) for r in rows]

    # ------------------------------------------------------------------ #
    #  Skill CRUD                                                          #
    # ------------------------------------------------------------------ #

    def insert_skill(self, skill, replace: bool = False) -> bool:
        cmd = "INSERT OR REPLACE" if replace else "INSERT OR IGNORE"
        cur = self._conn.execute(
            f"{cmd} INTO skills VALUES(?,?,?,?,?,?,?,?,?,?)",
            self._skill_to_row(skill),
        )
        self._conn.commit()
        return cur.rowcount > 0

    def get_skill(self, skill_id: str):
        row = self._conn.execute(
            "SELECT * FROM skills WHERE id=?", (skill_id,)
        ).fetchone()
        return self._row_to_skill(row) if row else None

    def list_skills(
        self,
        domain: Optional[str] = None,
        min_cs: int = 0,
        limit: int = 100,
    ):
        q = "SELECT * FROM skills WHERE civilization_score >= ?"
        params = [min_cs]
        if domain:
            q += " AND domain=?"
            params.append(domain)
        q += " ORDER BY civilization_score DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(q, params).fetchall()
        return [self._row_to_skill(r) for r in rows]

    def all_skills(self):
        rows = self._conn.execute("SELECT * FROM skills").fetchall()
        return [self._row_to_skill(r) for r in rows]

    # ------------------------------------------------------------------ #
    #  Community CRUD                                                      #
    # ------------------------------------------------------------------ #

    def insert_community(self, community) -> bool:
        cur = self._conn.execute(
            "INSERT OR IGNORE INTO communities(id,name,known_skills,created_at,notes) "
            "VALUES(?,?,?,?,?)",
            (
                community.id,
                community.name,
                json.dumps(community.known_skills),
                community.created_at.isoformat() if community.created_at else None,
                community.notes,
            ),
        )
        self._conn.commit()
        return cur.rowcount > 0

    def get_community(self, community_id: str):
        row = self._conn.execute(
            "SELECT * FROM communities WHERE id=?", (community_id,)
        ).fetchone()
        return self._row_to_community(row) if row else None

    def list_communities(self):
        rows = self._conn.execute("SELECT * FROM communities ORDER BY name").fetchall()
        return [self._row_to_community(r) for r in rows]

    def update_community_skills(self, community_id: str, known_skills):
        self._conn.execute(
            "UPDATE communities SET known_skills=? WHERE id=?",
            (json.dumps(list(known_skills)), community_id),
        )
        self._conn.commit()

    # ------------------------------------------------------------------ #
    #  Sync conflicts                                                      #
    # ------------------------------------------------------------------ #

    def insert_conflict(self, record_type: str, record_id: str, local_val: str, remote_val: str):
        from datetime import datetime
        self._conn.execute(
            "INSERT INTO sync_conflicts(record_type,record_id,local_value,remote_value,detected_at) "
            "VALUES(?,?,?,?,?)",
            (record_type, record_id, local_val, remote_val, datetime.utcnow().isoformat()),
        )
        self._conn.commit()

    def list_conflicts(self):
        return self._conn.execute(
            "SELECT * FROM sync_conflicts ORDER BY detected_at DESC"
        ).fetchall()

    # ------------------------------------------------------------------ #
    #  Raw connection access (for sync module)                            #
    # ------------------------------------------------------------------ #

    @property
    def connection(self):
        return self._conn

    def close(self):
        self._conn.close()

    # ------------------------------------------------------------------ #
    #  Row<->dataclass conversion helpers                                  #
    # ------------------------------------------------------------------ #

    @staticmethod
    def _article_to_row(a):
        from datetime import date as date_type
        return (
            a.id,
            a.title,
            a.domain,
            json.dumps(a.tags),
            a.civilization_score,
            a.difficulty,
            json.dumps(a.requires_skills),
            a.summary,
            a.content,
            json.dumps(a.sources),
            a.last_updated.isoformat() if isinstance(a.last_updated, date_type) else a.last_updated,
            int(a.custom),
        )

    @staticmethod
    def _row_to_article(row):
        from core.models import Article
        from datetime import date as date_type
        lu = row["last_updated"]
        return Article(
            id=row["id"],
            title=row["title"],
            domain=row["domain"],
            tags=json.loads(row["tags"]),
            civilization_score=row["civilization_score"],
            difficulty=row["difficulty"],
            requires_skills=json.loads(row["requires_skills"]),
            summary=row["summary"],
            content=row["content"],
            sources=json.loads(row["sources"]),
            last_updated=date_type.fromisoformat(lu) if lu else None,
            custom=bool(row["custom"]),
        )

    @staticmethod
    def _skill_to_row(s):
        return (
            s.id,
            s.title,
            s.domain,
            s.civilization_score,
            json.dumps(s.requires),
            json.dumps(s.unlocks),
            s.summary,
            s.difficulty,
            s.time_to_learn_days,
            int(s.custom),
        )

    @staticmethod
    def _row_to_skill(row):
        from core.models import Skill
        return Skill(
            id=row["id"],
            title=row["title"],
            domain=row["domain"],
            civilization_score=row["civilization_score"],
            requires=json.loads(row["requires"]),
            unlocks=json.loads(row["unlocks"]),
            summary=row["summary"],
            difficulty=row["difficulty"],
            time_to_learn_days=row["time_to_learn_days"],
            custom=bool(row["custom"]),
        )

    @staticmethod
    def _row_to_community(row):
        from core.models import Community
        from datetime import date as date_type
        ca = row["created_at"]
        return Community(
            id=row["id"],
            name=row["name"],
            known_skills=json.loads(row["known_skills"]),
            created_at=date_type.fromisoformat(ca) if ca else None,
            notes=row["notes"],
        )
