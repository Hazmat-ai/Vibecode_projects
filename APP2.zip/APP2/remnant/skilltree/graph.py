"""
skilltree/graph.py — Directed acyclic graph of skills.
Uses built-in adjacency lists for zero-dependency operation.
Optionally delegates to networkx when available.
"""

from typing import List, Optional, Set, TYPE_CHECKING

if TYPE_CHECKING:
    from core.models import Skill
    from core.db import Database


class SkillGraph:
    """
    In-memory skill graph backed by two adjacency dicts.
    forward_edges[A] = [B, C]  means A unlocks B and C (B,C require A)
    reverse_edges[B] = [A]     means B requires A (A is a dependent blocker of B)
    """

    def __init__(self, db: "Database"):
        self._db = db
        self._skills = {}        # id -> Skill
        self._forward = {}       # id -> list of ids that REQUIRE this skill
        self._reverse = {}       # id -> list of ids this skill REQUIRES
        self._load()

    def _load(self):
        """Load all skills from DB into memory."""
        for skill in self._db.all_skills():
            self._skills[skill.id] = skill
            self._forward.setdefault(skill.id, [])
            self._reverse[skill.id] = list(skill.requires)
            for req in skill.requires:
                self._forward.setdefault(req, [])
                self._forward[req].append(skill.id)

    def reload(self):
        """Reload graph from DB (call after inserting new skills)."""
        self._skills.clear()
        self._forward.clear()
        self._reverse.clear()
        self._load()

    # ------------------------------------------------------------------ #
    #  Core API (must match AGENT_CONTEXT spec)                           #
    # ------------------------------------------------------------------ #

    def get_skill(self, skill_id: str) -> Optional["Skill"]:
        return self._skills.get(skill_id)

    def get_dependents(self, skill_id: str) -> List[str]:
        """Return IDs of skills that list skill_id as a requirement."""
        return list(self._forward.get(skill_id, []))

    def get_unlockable(self, known: Set[str]) -> List["Skill"]:
        """Skills where ALL required skills are in `known`, and skill itself is not yet known."""
        result = []
        for skill_id, skill in self._skills.items():
            if skill_id in known:
                continue
            if all(req in known for req in skill.requires):
                result.append(skill)
        result.sort(key=lambda s: -s.civilization_score)
        return result

    def get_blocking(self, target_id: str, known: Set[str]) -> List["Skill"]:
        """Skills that must be learned before target_id is unlockable."""
        target = self._skills.get(target_id)
        if not target:
            return []
        blocking = []
        for req in target.requires:
            if req not in known:
                blocking.append(self._skills[req])
        return blocking

    def shortest_path(self, known: Set[str], target_id: str) -> List["Skill"]:
        """
        BFS to find the minimum ordered list of skills to learn
        to make target_id unlockable from the `known` set.
        Returns the skills to learn in order (not including already-known ones).
        """
        if target_id in known:
            return []
        if target_id not in self._skills:
            return []

        # Try networkx if available for potentially better algorithm
        try:
            return self._shortest_path_networkx(known, target_id)
        except (ImportError, Exception):
            pass

        return self._shortest_path_bfs(known, target_id)

    def _shortest_path_bfs(self, known: Set[str], target_id: str) -> List["Skill"]:
        """BFS on the dependency graph to find the path to target."""
        from collections import deque

        # Work backwards from target: find all ancestors not yet known
        needed = set()
        queue = deque([target_id])
        while queue:
            current = queue.popleft()
            if current in known or current in needed:
                continue
            needed.add(current)
            for req in self._reverse.get(current, []):
                if req not in known and req not in needed:
                    queue.append(req)

        # Topological sort of needed skills
        ordered = []
        resolved = set(known)
        remaining = set(needed)

        max_iterations = len(remaining) * len(remaining) + 1
        iteration = 0
        while remaining and iteration < max_iterations:
            iteration += 1
            for skill_id in list(remaining):
                reqs = self._reverse.get(skill_id, [])
                if all(r in resolved for r in reqs):
                    ordered.append(self._skills[skill_id])
                    resolved.add(skill_id)
                    remaining.remove(skill_id)

        return ordered

    def _shortest_path_networkx(self, known: Set[str], target_id: str) -> List["Skill"]:
        """Optional networkx-based implementation."""
        import networkx as nx  # type: ignore
        G = nx.DiGraph()
        for skill_id, reqs in self._reverse.items():
            for req in reqs:
                G.add_edge(req, skill_id)
        # Find all needed ancestors
        ancestors = nx.ancestors(G, target_id)
        needed = {a for a in ancestors if a not in known}
        needed.add(target_id)
        subgraph = G.subgraph(needed)
        try:
            order = list(nx.topological_sort(subgraph))
        except nx.NetworkXUnfeasible:
            return self._shortest_path_bfs(known, target_id)
        return [self._skills[s] for s in order if s in self._skills and s not in known]

    def all_skills(self) -> List["Skill"]:
        return list(self._skills.values())
