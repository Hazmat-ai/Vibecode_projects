"""
skilltree/renderer.py — ASCII art skill tree renderer.
No dependencies beyond stdlib. Gracefully degrades on non-UTF-8 terminals.
"""

import sys
from typing import Set, TYPE_CHECKING

if TYPE_CHECKING:
    from skilltree.graph import SkillGraph

_UTF8 = sys.stdout.encoding and sys.stdout.encoding.lower() in ("utf-8", "utf8")
_BRANCH = "├── " if _UTF8 else "+-- "
_LAST   = "└── " if _UTF8 else "\\-- "
_PIPE   = "│   " if _UTF8 else "|   "
_SPACE  = "    "
_KNOWN  = "[x]"
_LOCKED = "[ ]"


def render_tree(graph: "SkillGraph", known: Set[str], domain: str = None) -> str:
    """
    Render the skill tree as ASCII art.
    Root nodes are skills with no requirements.
    """
    all_skills = graph.all_skills()
    if domain:
        all_skills = [s for s in all_skills if s.domain == domain]

    skill_ids = {s.id for s in all_skills}
    roots = [s for s in all_skills if not any(r in skill_ids for r in s.requires)]
    roots.sort(key=lambda s: -s.civilization_score)

    lines = ["SKILL TREE", "=" * 50]
    for i, root in enumerate(roots):
        is_last = i == len(roots) - 1
        lines += _render_node(graph, root, known, "", is_last, skill_ids)
    return "\n".join(lines)


def _render_node(graph, skill, known, prefix, is_last, skill_ids):
    connector = _LAST if is_last else _BRANCH
    status = _KNOWN if skill.id in known else _LOCKED
    label = f"{status} {skill.title} (CS:{skill.civilization_score})"
    lines = [prefix + connector + label]

    child_prefix = prefix + (_SPACE if is_last else _PIPE)
    children = [
        graph.get_skill(cid)
        for cid in graph.get_dependents(skill.id)
        if cid in skill_ids and graph.get_skill(cid)
    ]
    children.sort(key=lambda s: -s.civilization_score)
    for i, child in enumerate(children):
        is_child_last = i == len(children) - 1
        lines += _render_node(graph, child, known, child_prefix, is_child_last, skill_ids)
    return lines
