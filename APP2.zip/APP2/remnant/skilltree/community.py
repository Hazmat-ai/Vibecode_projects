"""
skilltree/community.py — Manage community known/owned skill state.
"""

from datetime import date
from typing import List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from core.db import Database
    from core.models import Community


def create_community(db: "Database", name: str) -> "Community":
    from core.models import Community
    import re
    community_id = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    community = Community(
        id=community_id,
        name=name,
        known_skills=[],
        created_at=date.today(),
        notes="",
    )
    if not db.insert_community(community):
        raise ValueError(f"Community '{community_id}' already exists.")
    return community


def learn_skill(db: "Database", community_id: str, skill_id: str) -> bool:
    """Add skill_id to community's known set. Returns True if it was newly learned."""
    community = db.get_community(community_id)
    if not community:
        raise ValueError(f"Community '{community_id}' not found.")
    if skill_id in community.known_skills:
        return False
    community.known_skills.append(skill_id)
    db.update_community_skills(community_id, community.known_skills)
    return True


def unlearn_skill(db: "Database", community_id: str, skill_id: str) -> bool:
    """Remove skill_id from community's known set. Returns True if it was present."""
    community = db.get_community(community_id)
    if not community:
        raise ValueError(f"Community '{community_id}' not found.")
    if skill_id not in community.known_skills:
        return False
    community.known_skills.remove(skill_id)
    db.update_community_skills(community_id, community.known_skills)
    return True


def get_community(db: "Database", community_id: str) -> Optional["Community"]:
    return db.get_community(community_id)


def list_communities(db: "Database") -> List["Community"]:
    return db.list_communities()
