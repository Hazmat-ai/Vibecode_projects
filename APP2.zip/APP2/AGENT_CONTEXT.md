# AGENT_CONTEXT.md — REMNANT

This file is the authoritative context document for any AI coding agent (Claude, Copilot, Cursor, etc.) working on the REMNANT codebase. Read this before touching any file. Update it when the architecture changes.

---

## What This Project Is

REMNANT is a **100% offline, terminal-based Python application** for post-collapse communities. It combines two tools:

1. **The Last Library** — A curated survival knowledge encyclopedia stored in SQLite. Articles are ranked by "Civilization Score" (how critical this knowledge is to rebuilding society).

2. **The Skill Tree** — A directed acyclic graph (DAG) of human skills and technologies. Communities mark what they know; the app shows what they can unlock next and how to get there.

**Core constraint**: The app must run on Python 3.8+ with zero mandatory dependencies beyond the standard library. All third-party packages (`textual`, `networkx`, `rich`) are optional enhancements with graceful fallbacks.

---

## Current State of the Codebase

> **Update this section every time a module is completed or its API changes.**

| Module | Status | Notes |
|---|---|---|
| `core/db.py` | 🔲 Not started | |
| `core/models.py` | 🔲 Not started | |
| `core/search.py` | 🔲 Not started | |
| `core/sync.py` | 🔲 Not started | |
| `library/engine.py` | 🔲 Not started | |
| `library/scorer.py` | 🔲 Not started | |
| `library/exporter.py` | 🔲 Not started | |
| `skilltree/graph.py` | 🔲 Not started | |
| `skilltree/traversal.py` | 🔲 Not started | |
| `skilltree/community.py` | 🔲 Not started | |
| `skilltree/renderer.py` | 🔲 Not started | |
| `ui/plain.py` | 🔲 Not started | |
| `ui/tui.py` | 🔲 Not started | |
| `scripts/seed_db.py` | 🔲 Not started | |
| `main.py` | 🔲 Not started | |

Status legend: 🔲 Not started · 🟡 In progress · ✅ Complete · 🔴 Broken

---

## Absolute Rules for This Codebase

These are non-negotiable. Never violate them.

1. **No mandatory third-party imports at module load time.** Any import of `textual`, `networkx`, or `rich` must be inside a function, wrapped in `try/except ImportError`, with a plain-text fallback.

2. **The database is always a single file.** `data/remnant.db`. Never split state across multiple files. The app must be deployable by copying one folder.

3. **Python 3.8 minimum.** No walrus operator in critical paths, no `match` statements, no `3.10+` union types. Use `Optional[X]` not `X | None`.

4. **All user-facing text is plain ASCII unless the terminal supports UTF-8.** Detect at startup and degrade gracefully. Never crash on a terminal that can't render box-drawing characters.

5. **Never make network calls.** No `urllib`, `requests`, `httpx`, or socket calls anywhere in the application logic. The sync module transfers files via filesystem (USB), not network.

6. **Tests must run offline and without any optional dependencies.**

---

## Data Models

These are the canonical data structures. Match these exactly.

```python
# core/models.py

from dataclasses import dataclass, field
from typing import List, Optional
from datetime import date

@dataclass
class Article:
    id: str                          # kebab-case slug, globally unique
    title: str
    domain: str                      # food | medicine | engineering | governance | energy | communication | other
    tags: List[str]
    civilization_score: int          # 0-100
    difficulty: int                  # 1-5
    requires_skills: List[str]       # list of skill IDs
    summary: str                     # 1-3 sentence plain text summary
    content: str                     # full markdown content
    sources: List[str]
    last_updated: Optional[date] = None
    custom: bool = False             # True if user-added, False if from seed data

@dataclass
class Skill:
    id: str                          # kebab-case slug, globally unique
    title: str
    domain: str
    civilization_score: int          # 0-100
    requires: List[str]              # list of skill IDs that must be known first
    unlocks: List[str]               # list of skill IDs this makes available (denormalized cache)
    summary: str
    difficulty: int                  # 1-5
    time_to_learn_days: int
    custom: bool = False

@dataclass
class Community:
    id: str                          # user-chosen name/slug
    name: str
    known_skills: List[str] = field(default_factory=list)   # list of skill IDs
    created_at: Optional[date] = None
    notes: str = ""
```

---

## Database Schema

```sql
-- core/db.py is responsible for creating and migrating this schema

CREATE TABLE articles (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    domain TEXT NOT NULL,
    tags TEXT NOT NULL,             -- JSON array stored as text
    civilization_score INTEGER NOT NULL,
    difficulty INTEGER NOT NULL,
    requires_skills TEXT NOT NULL,  -- JSON array stored as text
    summary TEXT NOT NULL,
    content TEXT NOT NULL,
    sources TEXT NOT NULL,          -- JSON array stored as text
    last_updated TEXT,
    custom INTEGER NOT NULL DEFAULT 0
);

CREATE VIRTUAL TABLE articles_fts USING fts5(
    id UNINDEXED,
    title,
    summary,
    content,
    tags,
    content='articles',
    content_rowid='rowid'
);

CREATE TABLE skills (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    domain TEXT NOT NULL,
    civilization_score INTEGER NOT NULL,
    requires TEXT NOT NULL,         -- JSON array stored as text
    unlocks TEXT NOT NULL,          -- JSON array stored as text
    summary TEXT NOT NULL,
    difficulty INTEGER NOT NULL,
    time_to_learn_days INTEGER NOT NULL,
    custom INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE communities (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    known_skills TEXT NOT NULL DEFAULT '[]',  -- JSON array stored as text
    created_at TEXT,
    notes TEXT NOT NULL DEFAULT ''
);

CREATE TABLE meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
-- meta rows: schema_version, seed_version, created_at
```

---

## Key Algorithms

### Civilization Score (library/scorer.py)

The final CS for display is the seed/custom `base_score` (0-100) blended with a graph-derived `dependency_weight`. Do NOT recalculate on every read — cache in the `articles` and `skills` tables and invalidate when the graph changes.

```python
def compute_skill_cs(skill_id: str, graph: 'SkillGraph') -> int:
    base = graph.get_skill(skill_id).civilization_score
    dependents = len(graph.get_dependents(skill_id))   # skills that require this one
    dependency_bonus = min(20, dependents * 2)          # cap bonus at 20 points
    return min(100, base + dependency_bonus)
```

### Skill Tree Traversal (skilltree/traversal.py)

All traversal operates on a `SkillGraph` object backed by adjacency lists (not networkx — that's optional). The `SkillGraph` must implement:

```python
class SkillGraph:
    def get_unlockable(self, known: set[str]) -> list[Skill]:
        """Skills where ALL required skills are in `known`."""

    def get_blocking(self, target_id: str, known: set[str]) -> list[Skill]:
        """Skills that must be learned before `target_id` is unlockable."""

    def shortest_path(self, known: set[str], target_id: str) -> list[Skill]:
        """Ordered list of skills to learn to reach target. BFS on dependency graph."""

    def get_dependents(self, skill_id: str) -> list[str]:
        """Skills that list `skill_id` as a requirement (reverse edges)."""
```

When `networkx` is available, `SkillGraph` should delegate to it for algorithms. When not available, use the built-in BFS/DFS implementations in `skilltree/traversal.py`.

### Database Sync (core/sync.py)

Sync is **additive and non-destructive**. Never delete or overwrite existing records. Merge strategy:

- Articles: insert-if-not-exists by `id`. If `id` conflicts and content differs, keep local and flag conflict in a `sync_conflicts` table.
- Skills: insert-if-not-exists by `id`. Same conflict policy.
- Community known_skills: union of both sets. Knowledge only grows.
- Custom records (user-added) take precedence over seed records in conflicts.

---

## CLI Interface Contract

Built with `click`. All subcommands must work non-interactively (scriptable).

```
python main.py
python main.py library search <query> [--domain DOMAIN] [--limit N] [--min-cs N]
python main.py library read <id-or-title>
python main.py library top [--limit N] [--domain DOMAIN]
python main.py library add --file <path.yaml>
python main.py library export <id> [--format txt|md] [--output PATH]

python main.py tree show [--community ID] [--domain DOMAIN]
python main.py tree next --community <id> [--limit N]
python main.py tree path --skill <id> [--community ID]
python main.py tree learn --community <id> --skill <id>
python main.py tree unlearn --community <id> --skill <id>
python main.py community new <name>
python main.py community list

python main.py sync merge --source <path-to-remnant.db>
python main.py sync export --output <path>

python main.py --ui [plain|tui]   # override UI mode
python main.py --db <path>        # override DB path
```

Exit codes: `0` success, `1` user error (bad input), `2` internal error, `3` not found.

---

## UI Fallback Contract

Both `ui/plain.py` and `ui/tui.py` must implement the same `UIProtocol`:

```python
class UIProtocol:
    def show_article(self, article: Article) -> None: ...
    def show_skill(self, skill: Skill) -> None: ...
    def show_skill_list(self, skills: list[Skill], title: str) -> None: ...
    def show_article_list(self, articles: list[Article], title: str) -> None: ...
    def show_tree(self, graph: SkillGraph, known: set[str]) -> None: ...
    def prompt_choice(self, items: list[str], prompt: str) -> int: ...
    def show_error(self, message: str) -> None: ...
    def show_success(self, message: str) -> None: ...
```

`ui/plain.py` must never import anything outside stdlib.
`ui/tui.py` may import `textual` and `rich` freely.

Detection logic lives in `ui/__init__.py`:

```python
def get_ui(force: str = None) -> UIProtocol:
    if force == "plain":
        from ui.plain import PlainUI; return PlainUI()
    if force == "tui":
        from ui.tui import TUI; return TUI()
    try:
        import textual
        from ui.tui import TUI; return TUI()
    except ImportError:
        from ui.plain import PlainUI; return PlainUI()
```

---

## File Ownership

| File / Module | Who owns it | Notes |
|---|---|---|
| `core/` | Core team | Stable API — changes require updating this doc |
| `data/seed/` | Knowledge contributors | YAML only, never Python |
| `ui/plain.py` | UI team | Stdlib only |
| `ui/tui.py` | UI team | May use textual/rich |
| `scripts/` | DevOps | One-off scripts, not imported by app |

---

## Testing Guidelines

- All tests in `tests/` using `unittest` (stdlib only, no pytest required)
- Test data lives in `tests/fixtures/` — never touch `data/remnant.db` in tests
- Each test creates a fresh in-memory SQLite database: `db = Database(":memory:")`
- Cover these cases at minimum:
  - `test_graph.py`: unlockable detection, blocking detection, shortest path, cycle detection
  - `test_search.py`: exact match, partial match, multi-word, empty result, domain filter
  - `test_scorer.py`: base score only, dependency bonus, cap at 100
  - `test_sync.py`: clean merge, conflict detection, community union

---

## Seed Data Guidelines

When writing seed articles or skills in `data/seed/`:

- `civilization_score` should reflect **leverage** — how many other things depend on knowing this
- Write for a reader with a 10th-grade education and no internet
- Content must be actionable with minimal tools (list what tools are needed explicitly)
- Prefer knowledge that works in multiple climates and geographies
- Every article must have at least one `See Also` link to a related article

Priority order for seed content:
1. Water (purification, finding, storing)
2. Food (growing, preserving, foraging)
3. Medicine (wound care, infection, childbirth basics)
4. Shelter (construction, insulation, fire)
5. Energy (fire, simple machines, water power)
6. Communication (writing systems, signal, record-keeping)
7. Governance (dispute resolution, resource allocation, census)
8. Manufacturing (tools, metallurgy, textiles)

---

## What NOT to Build (Scope Boundaries)

- No networking features of any kind
- No authentication or user accounts
- No images or binary media in the database
- No voice/audio features
- No map or GPS features
- No AI/LLM integration inside the app itself
- No web interface (this is a terminal app)
- No cloud sync — USB only

---

## Questions a New Agent Should Ask Before Coding

1. Does the module I'm about to write have optional dependencies? If yes, is the fallback implemented first?
2. Am I touching `core/models.py`? If yes, did I update the DB schema and this AGENT_CONTEXT?
3. Is this function being called in a hot path (e.g. search results loop)? If yes, is there a caching layer?
4. Does my new CLI command follow the contract defined in the CLI Interface Contract section above?
5. Am I writing a test that touches `data/remnant.db`? If yes, switch to `:memory:`.

---

*Last updated: project inception. Update this document whenever the architecture, models, or API contracts change.*
