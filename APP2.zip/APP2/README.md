# 🌍 REMNANT — Knowledge for the Road Back

> *"Civilization is not a destination. It's a direction."*

REMNANT is an offline-first, terminal-based Python application combining a survival knowledge encyclopedia with an interactive civilization skill tree. It is designed to run on any hardware — old laptops, Raspberry Pis, solar-powered terminals — with zero internet dependency.

---

## Table of Contents

- [Philosophy](#philosophy)
- [Features](#features)
- [Architecture](#architecture)
- [Installation](#installation)
- [Usage](#usage)
- [Data Format](#data-format)
- [Modules](#modules)
- [Contributing Knowledge](#contributing-knowledge)
- [Roadmap](#roadmap)
- [License](#license)

---

## Philosophy

Most encyclopedias are built for curiosity. REMNANT is built for survival.

Every article, skill, and technology in REMNANT is assigned a **Civilization Score (CS)** — a measure of how foundational it is to rebuilding a stable society. CS is not about complexity; it's about *leverage*. Clean water outscores quantum computing. Fire-starting outscores finance.

The two pillars:

**1. The Last Library** — A curated, offline knowledge base of practical survival and rebuilding knowledge. Articles are ranked by Civilization Score and tagged by domain (Food, Medicine, Engineering, Governance, etc.). Designed to be read by candlelight on a ten-year-old laptop.

**2. The Skill Tree** — An interactive directed graph of human technological and social capability. Every node is a skill or technology. Every edge is a dependency. Given what your community already knows, the Skill Tree tells you what you can unlock next — and what's blocking you.

---

## Features

- **100% offline** — no internet required at runtime
- **Runs in terminal** — works on any Python 3.8+ system, including Raspberry Pi
- **Optional TUI** — rich terminal UI via `textual` if available; falls back to plain text
- **Civilization Score ranking** — every article and skill is weighted by rebuilding value
- **Skill dependency engine** — graph traversal showing what your community can unlock
- **Full-text search** — fast local search across all articles and skills
- **Portable database** — everything stored in a single SQLite file; copy it on a USB drive
- **Export to plaintext** — any article or skill can be exported to a simple `.txt` file for printing
- **Community knowledge input** — add custom articles and skills via CLI or YAML files
- **Offline-first sync** — merge two REMNANT databases when communities reconnect

---

## Architecture

```
remnant/
│
├── main.py                  # Entry point — CLI router
├── config.py                # App-wide settings and constants
│
├── core/
│   ├── db.py                # SQLite interface (single .db file)
│   ├── models.py            # Dataclasses: Article, Skill, Edge, Tag
│   ├── search.py            # Full-text search engine (FTS5 via SQLite)
│   └── sync.py              # Database merge / community sync logic
│
├── library/
│   ├── engine.py            # Article retrieval, ranking, filtering
│   ├── scorer.py            # Civilization Score calculation logic
│   └── exporter.py          # Export articles to .txt, .md, or print
│
├── skilltree/
│   ├── graph.py             # Directed graph of skills (networkx or built-in)
│   ├── traversal.py         # BFS/DFS to find unlockable skills
│   ├── community.py         # Manage community's known/owned skills
│   └── renderer.py          # ASCII art tree renderer (no dependencies)
│
├── ui/
│   ├── tui.py               # Textual TUI (optional, graceful fallback)
│   ├── plain.py             # Plain terminal interface (always available)
│   └── prompts.py           # Shared input/output helpers
│
├── data/
│   ├── seed/
│   │   ├── articles/        # Seed knowledge articles (.yaml or .md)
│   │   └── skills/          # Seed skill definitions (.yaml)
│   └── remnant.db           # Generated SQLite database (not in repo)
│
├── scripts/
│   ├── seed_db.py           # Populate database from seed data files
│   ├── import_article.py    # Import a single article from file
│   └── export_db.py         # Export full DB to human-readable folder
│
├── tests/
│   ├── test_graph.py
│   ├── test_search.py
│   ├── test_scorer.py
│   └── test_sync.py
│
├── requirements.txt
├── requirements-optional.txt
└── README.md
```

---

## Installation

### Minimum (any system with Python)

```bash
git clone https://github.com/yourname/remnant
cd remnant
pip install -r requirements.txt
python scripts/seed_db.py       # Build the database from seed data
python main.py
```

### With optional TUI (recommended if screen > 80 cols)

```bash
pip install -r requirements-optional.txt
python main.py --ui tui
```

### On a Raspberry Pi (offline deployment)

```bash
# On a connected machine:
pip download -r requirements.txt -d ./pip-cache

# Transfer remnant/ folder to Pi via USB, then on the Pi:
pip install --no-index --find-links=./pip-cache -r requirements.txt
python scripts/seed_db.py
python main.py
```

### Dependencies

**Required (`requirements.txt`)**
```
click>=8.0          # CLI framework
pyyaml>=6.0         # Seed data parsing
```

**Optional (`requirements-optional.txt`)**
```
textual>=0.50       # Rich terminal UI
networkx>=3.0       # Advanced graph algorithms for skill tree
rich>=13.0          # Pretty terminal output
```

> REMNANT is intentionally designed to run with only Python's standard library if needed. All optional packages enhance the experience but are never required.

---

## Usage

```bash
# Launch interactive menu
python main.py

# Search the library
python main.py library search "water purification"

# Read an article by ID or title
python main.py library read "fire-making"

# List top articles by Civilization Score
python main.py library top --limit 20 --domain medicine

# Show the full skill tree
python main.py tree show

# Show what skills your community can unlock next
python main.py tree next --community my_settlement

# Mark a skill as known
python main.py tree learn --community my_settlement --skill "crop-rotation"

# Show what's blocking you from a specific skill
python main.py tree path --skill "iron-smelting"

# Add a custom article
python main.py library add --file my_article.yaml

# Merge two community databases
python main.py sync merge --source /media/usb/remnant.db
```

---

## Data Format

### Article (YAML)

```yaml
id: water-purification-boiling
title: Water Purification — Boiling
domain: medicine
tags: [water, health, fire, survival]
civilization_score: 95        # 0-100, how critical to rebuilding
difficulty: 1                 # 1-5, how hard to learn/apply
requires_skills: [fire-making]
summary: >
  Boiling is the most reliable low-tech method to kill pathogens in water.
  Requires only a container and a heat source.
content: |
  ## Why It Works
  Most waterborne pathogens — bacteria, viruses, protozoa — are killed
  at temperatures well below boiling point (70°C / 158°F).
  Reaching a rolling boil for 1 minute is sufficient at most elevations.

  ## What You Need
  - A heat-safe container (metal pot, clay vessel, rock cavity)
  - A reliable fire
  - Water from any source

  ## Steps
  1. Fill container with water from the source.
  2. Bring to a full rolling boil.
  3. Maintain boil for 1 minute (3 minutes above 2000m elevation).
  4. Let cool before drinking. Cover to prevent recontamination.

  ## Limitations
  Boiling does NOT remove chemical contamination, heavy metals,
  or sediment. Combine with filtration for best results.

  ## See Also
  - water-filtration-improvised
  - solar-disinfection-sodis
sources:
  - WHO Guidelines for Drinking-water Quality, 4th Edition
last_updated: 2024-01-01
```

### Skill (YAML)

```yaml
id: crop-rotation
title: Crop Rotation
domain: food
civilization_score: 80
requires: [basic-agriculture, soil-understanding]
unlocks: [cover-cropping, three-field-system, nitrogen-fixation-awareness]
summary: >
  Rotating which crops are planted in a field each season to prevent
  soil depletion, reduce pests, and increase long-term yields.
difficulty: 2
time_to_learn_days: 30
```

---

## Modules

### `library/scorer.py` — Civilization Score Engine

The Civilization Score (CS) is a composite of:

| Factor | Weight | Description |
|---|---|---|
| `base_score` | 40% | Hand-curated score from domain experts |
| `dependency_multiplier` | 30% | How many other skills depend on this one |
| `population_impact` | 20% | How many people this directly benefits |
| `resource_scarcity` | 10% | How available the required materials are |

Scores are recalculated when the skill graph changes (e.g. when a community marks skills as known, dependencies shift).

---

### `skilltree/graph.py` — The Skill Tree

The skill tree is a **Directed Acyclic Graph (DAG)**:

- **Nodes**: Skills and technologies
- **Edges**: Dependency relationships (`A → B` means "B requires A")
- **State**: Each community has a set of "known" nodes

Key operations:
- `get_unlockable(community)` — skills where all dependencies are met
- `get_blocking(skill)` — what skills are missing to reach a target
- `shortest_path(known_set, target)` — minimum skills to learn to reach a goal
- `critical_path()` — highest-CS skills reachable within N steps

---

### `core/sync.py` — Community Sync

When two communities meet and share USB drives, they can merge knowledge:

- New articles from either side are added
- Skill "known" states are unioned (knowledge only grows)
- Conflicts in article content are flagged for human review
- A sync log tracks what was exchanged and when

---

## Contributing Knowledge

The seed knowledge base is a living document. To add or improve articles:

1. Write your article in the YAML format above
2. Place it in `data/seed/articles/`
3. Run `python scripts/seed_db.py --update` to rebuild
4. Submit a pull request with your addition

**Priority domains for contributions:**
- Water purification and sanitation
- Agriculture and soil science  
- Basic medicine and wound care
- Shelter construction
- Food preservation
- Basic metallurgy
- Governance and conflict resolution

---

## Roadmap

### v0.1 — Foundation
- [x] SQLite database schema
- [x] Article YAML parser and seed loader
- [x] Full-text search (FTS5)
- [x] Basic CLI (`library search`, `library read`, `library top`)
- [x] Skill graph data model and YAML loader

### v0.2 — Skill Tree
- [ ] Skill dependency graph engine
- [ ] Community state management
- [ ] `tree next` — show unlockable skills
- [ ] `tree path` — pathfinding to target skill
- [ ] ASCII tree renderer

### v0.3 — UI
- [ ] Plain terminal interactive menu
- [ ] Textual TUI (optional)
- [ ] Article pagination and formatting
- [ ] Civilization Score leaderboard view

### v0.4 — Community Features
- [ ] Multi-community profiles
- [ ] Database merge / sync
- [ ] Export to printable plaintext

### v1.0 — Field Ready
- [ ] Raspberry Pi deployment guide
- [ ] Seed knowledge base: 200+ articles, 150+ skills
- [ ] Single-file executable (PyInstaller)
- [ ] Offline installer package (no pip required)

---

## License

MIT License. Copy it. Print it. Share it. The whole point is that it survives.

---

*Built for the world we hope never comes, and the people who'd need it if it did.*
